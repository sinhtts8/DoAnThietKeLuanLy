#include "task_webserver.h"

// Async server duoc tach sang cong 8080 de khong tranh chap voi MainServer (80).
AsyncWebServer asyncServer(8080);
AsyncWebSocket ws("/ws");

bool webserver_isrunning = false;

void Webserver_sendata(String data)
{
    if (ws.count() > 0)
    {
        ws.textAll(data); // Gửi đến tất cả client đang kết nối
        Serial.println("📤 Đã gửi dữ liệu qua WebSocket: " + data);
    }
    else
    {
        Serial.println("⚠️ Không có client WebSocket nào đang kết nối!");
    }
}

void onEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len)
{
    if (type == WS_EVT_CONNECT)
    {
        Serial.printf("WebSocket client #%u connected from %s\n", client->id(), client->remoteIP().toString().c_str());
    }
    else if (type == WS_EVT_DISCONNECT)
    {
        Serial.printf("WebSocket client #%u disconnected\n", client->id());
    }
    else if (type == WS_EVT_DATA)
    {
        AwsFrameInfo *info = (AwsFrameInfo *)arg;

        if (info->opcode == WS_TEXT)
        {
            String message;
            message += String((char *)data).substring(0, len);
            // parseJson(message, true);
            handleWebSocketMessage(message);
        }
    }
}

void connnectWSV()
{
    ws.onEvent(onEvent);
    asyncServer.addHandler(&ws);
    asyncServer.on("/", HTTP_GET, [](AsyncWebServerRequest *request)
                   { request->send(LittleFS, "/index.html", "text/html"); });
    asyncServer.on("/script.js", HTTP_GET, [](AsyncWebServerRequest *request)
                   { request->send(LittleFS, "/script.js", "application/javascript"); });
    asyncServer.on("/styles.css", HTTP_GET, [](AsyncWebServerRequest *request)
                   { request->send(LittleFS, "/styles.css", "text/css"); });
    asyncServer.on("/health", HTTP_GET, [](AsyncWebServerRequest *request)
                   { request->send(200, "text/plain", "AsyncWebServer is working!"); });
    ElegantOTA.begin(&asyncServer);
    asyncServer.begin();
    Serial.println("AsyncWebServer started on port 8080");

    webserver_isrunning = true;
}

void Webserver_stop()
{
    ws.closeAll();
    asyncServer.end();
    webserver_isrunning = false;
}

void Webserver_reconnect()
{
    // AsyncWebServer/ElegantOTA cung chi khoi dong sau khi Wi-Fi co IP.
    if (!isNetworkReady)
    {
        return;
    }

    if (!webserver_isrunning)
    {
        connnectWSV();
    }
    ElegantOTA.loop();
}
